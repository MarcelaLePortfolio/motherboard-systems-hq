# Mission Control Presentation v1 — Bundle Manifest

## Included authority

- CLAUDE_TASK.md
- Mission Control Presentation Specification
- Approved Mission Control mockup
- Bounded frontend implementation files

## Excluded authority

- Backend runtime
- Database
- Mission Read architecture
- Governance architecture
- Package semantics
- Delegation semantics
- Envelope semantics
- Project context
- Conversation architecture
- Disaster Recovery tooling

## Implementation Rule

The specification governs semantic meaning.

The mockup governs visual composition.

Existing frontend integration governs authoritative data access.

If those conflict, stop and report the conflict rather than inventing behavior.
